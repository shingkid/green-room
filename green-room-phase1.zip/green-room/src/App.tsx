import './index.css'
import { ThemeProvider } from './themes'
import { ThemeSwitcher } from './components/ThemeSwitcher'

/**
 * Phase 1 demo — shows the token system + switcher in isolation.
 * Replace the inner content with full app layout in Phase 2.
 */
function AppShell() {
  return (
    <div style={{
      minHeight: '100vh',
      background: 'var(--color-bg-base)',
      color: 'var(--color-text-primary)',
      fontFamily: 'var(--font-base)',
      display: 'flex',
      flexDirection: 'column',
    }}>
      {/* Header */}
      <header style={{
        background: 'var(--color-bg-header)',
        borderBottom: '1px solid var(--color-border)',
        padding: '10px 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div>
          <div style={{
            fontSize: 'var(--font-size-md)',
            fontWeight: 'var(--font-weight-bold)',
            letterSpacing: '-0.02em',
          }}>
            ◈ green-room
          </div>
          <div style={{ fontSize: 'var(--font-size-xs)', opacity: 0.4, marginTop: 1 }}>
            service dependency explorer
          </div>
        </div>
        <ThemeSwitcher />
      </header>

      {/* Body placeholder */}
      <main style={{
        flex: 1,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        flexDirection: 'column',
        gap: 12,
        padding: 32,
      }}>
        <div style={{
          fontSize: 'var(--font-size-md)',
          fontWeight: 'var(--font-weight-bold)',
          color: 'var(--color-text-primary)',
        }}>
          Phase 1 complete — token system + theme switcher ✓
        </div>
        <div style={{
          fontSize: 'var(--font-size-sm)',
          color: 'var(--color-text-muted)',
          maxWidth: 400,
          textAlign: 'center',
          lineHeight: 1.6,
        }}>
          All 26 tokens are live on <code style={{ fontFamily: 'var(--font-mono)', color: 'var(--color-accent)' }}>:root</code>.
          Switch themes above — the transition is CSS-only, zero re-renders.
          Phase 2 will add the full page layout.
        </div>

        {/* Token preview strip */}
        <div style={{
          display: 'flex',
          gap: 6,
          marginTop: 16,
          flexWrap: 'wrap',
          justifyContent: 'center',
        }}>
          {[
            ['--color-accent',       'accent'],
            ['--color-accent2',      'accent2'],
            ['--color-status-ok',    'ok'],
            ['--color-status-warn',  'warn'],
            ['--color-status-err',   'err'],
            ['--color-edge-dep',     'edge-dep'],
            ['--color-edge-call',    'edge-call'],
          ].map(([cssVar, label]) => (
            <div key={cssVar} style={{
              display: 'flex',
              alignItems: 'center',
              gap: 5,
              background: 'var(--color-bg-surface)',
              border: '1px solid var(--color-border)',
              borderRadius: 'var(--radius-chip)',
              padding: '4px 9px',
              fontSize: 'var(--font-size-xs)',
              color: 'var(--color-text-secondary)',
              fontFamily: 'var(--font-mono)',
            }}>
              <span style={{
                width: 10, height: 10,
                borderRadius: '50%',
                background: `var(${cssVar})`,
                flexShrink: 0,
              }} />
              {label}
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}

export default function App() {
  return (
    <ThemeProvider defaultThemeId="d-light">
      <AppShell />
    </ThemeProvider>
  )
}
